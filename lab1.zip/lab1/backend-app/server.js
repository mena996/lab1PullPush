const express = require('express');
const cors = require('cors');

const port = process.env.port || 5000;
const app = express();
const subscribers = {};

app.use(express.json());
app.use(cors());

const messages = [];
const responses = {};

app.get('/messages', (req, res, next) => {
    res.json(messages);
});
app.post('/messages', (req, res, next) => {
    const { body } = req;
    console.log('user', body.user, 'new message', body.content);
    messages.push(body);
    sendToAll(body)
    res.status(204).end();
}); 

function sendToAll(mesObj){
    console.log(responses);
    Object.keys(responses).forEach((id) => {
        console.log(id);
        responses[id].send(mesObj);
        delete responses[id];
    });
}

app.post('/subscribe', (req, res, next) => {
    const { id } = req.body;
    console.log('new sub:', id);
    req.on('close', () => delete responses[id]);
    responses[id] = res;
});

app.use((err, req, res, next) => {
    res.send("oh no there is some thing wrong happend :( \n" + err);
});
app.listen(port, (err) => {
    if (!err) console.log(`started new server on port ${port}`)
})